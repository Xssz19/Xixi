X合约计算器 Android v1.0
上传 ZIP 解压后的全部文件到 GitHub 仓库根目录（包含 .github 文件夹），进入 Actions -> Build Android APK -> Run workflow，完成后在 Artifacts 下载 APK。
原 HTML 逻辑保留，数据存储于 App 本地 WebView。
