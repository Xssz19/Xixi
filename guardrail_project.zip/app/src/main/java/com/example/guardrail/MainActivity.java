package com.example.guardrail;
import android.app.*;import android.os.*;import android.content.*;import android.webkit.*;import android.print.*;import android.util.Base64;import java.io.*;
public class MainActivity extends Activity {
 WebView web; String pendingName; byte[] pendingBytes; static final int SAVE=100;
 @Override public void onCreate(Bundle b){super.onCreate(b);web=new WebView(this);setContentView(web);web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.addJavascriptInterface(new Object(){
 @JavascriptInterface public void saveXlsx(String filename,String b64){pendingName=filename;pendingBytes=Base64.decode(b64,Base64.DEFAULT);runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");i.putExtra(Intent.EXTRA_TITLE,filename);startActivityForResult(i,SAVE);});}
 @JavascriptInterface public void printPdf(){runOnUiThread(()->{PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);pm.print("护栏生产尺寸图",web.createPrintDocumentAdapter("护栏生产尺寸图"),new PrintAttributes.Builder().build());});}
 },"Android");web.loadUrl("file:///android_asset/index.html");}
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==SAVE&&result==RESULT_OK&&data!=null){try(OutputStream os=getContentResolver().openOutputStream(data.getData())){os.write(pendingBytes);Toast.makeText(this,"Excel已保存",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"保存失败: "+e.getMessage(),Toast.LENGTH_LONG).show();}}}
 @Override public void onBackPressed(){web.evaluateJavascript("backPage()",null);}
}
