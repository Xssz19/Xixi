package com.xssz.contractcalculator;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.graphics.Color;
import android.view.WindowManager;
public class MainActivity extends Activity {
 private WebView web;
 @Override public void onCreate(Bundle savedInstanceState){super.onCreate(savedInstanceState);getWindow().setStatusBarColor(Color.rgb(15,20,25));getWindow().setNavigationBarColor(Color.rgb(15,20,25));web=new WebView(this);web.setBackgroundColor(Color.rgb(15,20,25));web.setWebViewClient(new WebViewClient());WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);settings.setAllowFileAccess(true);setContentView(web);web.loadUrl("file:///android_asset/index.html");}
 @Override protected void onDestroy(){web.destroy();super.onDestroy();}
}
